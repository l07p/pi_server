--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.6 (Ubuntu 14.6-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.6 (Ubuntu 14.6-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "KMLicense";
--
-- Name: KMLicense; Type: DATABASE; Schema: -; Owner: licenseMgt
--

CREATE DATABASE "KMLicense" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE "KMLicense" OWNER TO "licenseMgt";

\connect "KMLicense"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tbl_user_computer_conf; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_user_computer_conf (
    user_id integer,
    computer_id integer
);


ALTER TABLE public.tbl_user_computer_conf OWNER TO "licenseMgt";

--
-- Name: activity_assign_computer_to_user(integer, integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_assign_computer_to_user(p_user_id integer, p_computer_id integer) RETURNS public.tbl_user_computer_conf
    LANGUAGE sql
    AS $$INSERT INTO tbl_user_computer_conf (user_id, computer_id)( SELECT p_user_id, p_computer_id )
RETURNING user_id, computer_id
$$;


ALTER FUNCTION public.activity_assign_computer_to_user(p_user_id integer, p_computer_id integer) OWNER TO "licenseMgt";

--
-- Name: tbl_contract_contact_person_conf; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_contract_contact_person_conf (
    contract_id integer,
    contact_person_id integer
);


ALTER TABLE public.tbl_contract_contact_person_conf OWNER TO "licenseMgt";

--
-- Name: activity_assign_contact_person_to_contract(integer, integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_assign_contact_person_to_contract(p_contract_id integer, p_contactperson_id integer) RETURNS public.tbl_contract_contact_person_conf
    LANGUAGE sql
    AS $$
INSERT INTO tbl_contract_contact_person_conf (contract_id, contact_person_id)
(SELECT p_contract_id, p_contactperson_id)
RETURNING contract_id, contact_person_id$$;


ALTER FUNCTION public.activity_assign_contact_person_to_contract(p_contract_id integer, p_contactperson_id integer) OWNER TO "licenseMgt";

--
-- Name: tbl_license_flag_set_defined_contract_conf; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_license_flag_set_defined_contract_conf (
    license_flag_set_defined_id integer,
    contract_id integer
);


ALTER TABLE public.tbl_license_flag_set_defined_contract_conf OWNER TO "licenseMgt";

--
-- Name: activity_assign_license_flag_set_defined_to_contract(integer, integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_assign_license_flag_set_defined_to_contract(p_license_flag_set_defined_id integer, p_contract_id integer) RETURNS public.tbl_license_flag_set_defined_contract_conf
    LANGUAGE sql
    AS $$

INSERT INTO tbl_license_flag_set_defined_contract_conf (license_flag_set_defined_id, contract_id)
(SELECT p_license_flag_set_defined_id, p_contract_id)
RETURNING license_flag_set_defined_id, contract_id

$$;


ALTER FUNCTION public.activity_assign_license_flag_set_defined_to_contract(p_license_flag_set_defined_id integer, p_contract_id integer) OWNER TO "licenseMgt";

--
-- Name: tbl_license_flag_set_issued_computer_conf; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_license_flag_set_issued_computer_conf (
    license_flag_set_issued_id integer,
    computer_id integer
);


ALTER TABLE public.tbl_license_flag_set_issued_computer_conf OWNER TO "licenseMgt";

--
-- Name: activity_assign_license_flag_set_issued_to_computer(integer, integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_assign_license_flag_set_issued_to_computer(p_license_flag_set_issued_id integer, p_computer_id integer) RETURNS public.tbl_license_flag_set_issued_computer_conf
    LANGUAGE sql
    AS $$
INSERT INTO tbl_license_flag_set_issued_computer_conf (license_flag_set_issued_id, computer_id)
(SELECT p_license_flag_set_issued_id, p_computer_id)
RETURNING license_flag_set_issued_id, computer_id
$$;


ALTER FUNCTION public.activity_assign_license_flag_set_issued_to_computer(p_license_flag_set_issued_id integer, p_computer_id integer) OWNER TO "licenseMgt";

--
-- Name: tbl_license_flag_set_issued_user_conf; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_license_flag_set_issued_user_conf (
    license_flag_set_issued_id integer,
    user_id integer
);


ALTER TABLE public.tbl_license_flag_set_issued_user_conf OWNER TO "licenseMgt";

--
-- Name: activity_assign_license_flag_set_issued_to_user(integer, integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_assign_license_flag_set_issued_to_user(p_license_flag_set_issued_id integer, p_user_id integer) RETURNS public.tbl_license_flag_set_issued_user_conf
    LANGUAGE sql
    AS $$
INSERT INTO tbl_license_flag_set_issued_user_conf (license_flag_set_issued_id, user_id)
(SELECT p_license_flag_set_issued_id, p_user_id)
RETURNING license_flag_set_issued_id, user_id
$$;


ALTER FUNCTION public.activity_assign_license_flag_set_issued_to_user(p_license_flag_set_issued_id integer, p_user_id integer) OWNER TO "licenseMgt";

--
-- Name: tbl_license_flag_set_defined_conf; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_license_flag_set_defined_conf (
    license_flag_set_defined_id integer,
    license_flag_id integer
);


ALTER TABLE public.tbl_license_flag_set_defined_conf OWNER TO "licenseMgt";

--
-- Name: activity_assign_license_flag_to_license_flag_set_defined(integer, integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_assign_license_flag_to_license_flag_set_defined(p_license_flag_set_defined_id integer, p_license_flag_id integer) RETURNS public.tbl_license_flag_set_defined_conf
    LANGUAGE sql
    AS $$

INSERT INTO tbl_license_flag_set_defined_conf(license_flag_set_defined_id, license_flag_id)
(SELECT p_license_flag_set_defined_id, p_license_flag_id)
RETURNING license_flag_set_defined_id, license_flag_id

$$;


ALTER FUNCTION public.activity_assign_license_flag_to_license_flag_set_defined(p_license_flag_set_defined_id integer, p_license_flag_id integer) OWNER TO "licenseMgt";

--
-- Name: tbl_license_flag_set_issued_conf; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_license_flag_set_issued_conf (
    license_flag_set_issued_id integer,
    license_flag_id integer
);


ALTER TABLE public.tbl_license_flag_set_issued_conf OWNER TO "licenseMgt";

--
-- Name: activity_assign_license_flag_to_license_flag_set_issued(integer, integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_assign_license_flag_to_license_flag_set_issued(p_license_flag_set_issued_id integer, p_license_flag_id integer) RETURNS public.tbl_license_flag_set_issued_conf
    LANGUAGE sql
    AS $$

INSERT INTO tbl_license_flag_set_issued_conf(license_flag_set_issued_id, license_flag_id)
(SELECT p_license_flag_set_issued_id, p_license_flag_id)
RETURNING license_flag_set_issued_id, license_flag_id

$$;


ALTER FUNCTION public.activity_assign_license_flag_to_license_flag_set_issued(p_license_flag_set_issued_id integer, p_license_flag_id integer) OWNER TO "licenseMgt";

--
-- Name: tbl_contract_user_conf; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_contract_user_conf (
    contract_id integer,
    user_id integer
);


ALTER TABLE public.tbl_contract_user_conf OWNER TO "licenseMgt";

--
-- Name: activity_assign_user_to_contract(integer, integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_assign_user_to_contract(p_contract_id integer, p_user_id integer) RETURNS public.tbl_contract_user_conf
    LANGUAGE sql
    AS $$INSERT INTO tbl_contract_user_conf (contract_id, user_id)
(SELECT p_contract_id, p_user_id)
RETURNING contract_id, user_id
$$;


ALTER FUNCTION public.activity_assign_user_to_contract(p_contract_id integer, p_user_id integer) OWNER TO "licenseMgt";

--
-- Name: activity_block_computer_with_id(integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_block_computer_with_id(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int integer;

BEGIN

    UPDATE tbl_computers
      SET (blocked) 
        = (TRUE)
      WHERE id = p_id;
    v_int := p_id;  

  RETURN v_int;
END;
$$;


ALTER FUNCTION public.activity_block_computer_with_id(p_id integer) OWNER TO "licenseMgt";

--
-- Name: activity_block_user_with_id(integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_block_user_with_id(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int integer;

BEGIN

    UPDATE tbl_users
      SET (blocked) 
        = (TRUE)
      WHERE id = p_id;
    v_int := p_id;  

  RETURN v_int;
END;
$$;


ALTER FUNCTION public.activity_block_user_with_id(p_id integer) OWNER TO "licenseMgt";

--
-- Name: activity_create_license_flag_set_defined(text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_create_license_flag_set_defined(p_memo text) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
  v_id integer;
  v_created_date timestamp with time zone;

BEGIN
  v_created_date := now();
      
  INSERT INTO tbl_license_flag_set_defined(create_date,memo)
				VALUES(v_created_date, p_memo);
  SELECT last_value FROM tbllicenseflagsetdefined_id_seq INTO v_id;
  
  RETURN v_id;
END;

$$;


ALTER FUNCTION public.activity_create_license_flag_set_defined(p_memo text) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_create_license_flag_set_defined(p_memo text); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_create_license_flag_set_defined(p_memo text) IS 'This function creates a new entry in table tbl_license_flag_set_defined. 

Return id, integer. The id is of new created data set.';


--
-- Name: activity_create_license_flag_set_issued(timestamp with time zone, text, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_create_license_flag_set_issued(p_valid_until_date timestamp with time zone, p_memo text, p_valid_version text DEFAULT '2.99.99'::text) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
  v_id integer;
  v_created_date timestamp with time zone;

BEGIN
  v_created_date := now();
      
  INSERT INTO tbl_license_flag_set_issued(valid_until_date, valid_version, create_date,memo)
				VALUES(p_valid_until_date, p_valid_version, v_created_date, p_memo);
  SELECT last_value FROM tbllicenseflagsetissued_id_seq INTO v_id;
  
  RETURN v_id;
END;
$$;


ALTER FUNCTION public.activity_create_license_flag_set_issued(p_valid_until_date timestamp with time zone, p_memo text, p_valid_version text) OWNER TO "licenseMgt";

--
-- Name: activity_create_license_flag_set_of_user_on_his_contracts(integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_create_license_flag_set_of_user_on_his_contracts(p_user_id integer DEFAULT 0) RETURNS integer[]
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_contracts integer[];
    v_lfs_defined_array integer[];
    ret_val integer[];
    i integer;
    
BEGIN

    SELECT activity_find_contracts_with_user(p_user_id) 
    INTO v_contracts;
     
    SELECT activity_create_license_flag_set_with_given_contracts(v_contracts) 
    INTO ret_val; 
    
    RETURN ret_val;
END;

$$;


ALTER FUNCTION public.activity_create_license_flag_set_of_user_on_his_contracts(p_user_id integer) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_create_license_flag_set_of_user_on_his_contracts(p_user_id integer); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_create_license_flag_set_of_user_on_his_contracts(p_user_id integer) IS 'This function returns an array, defined license flags are listed in the array
1. input user id
2. list all his contracts
3. list all license_flag_set_defined to the contracts, each contract has one defined lfs that the latest is taken
4. merge all license flags to a new license_flag_set. license flag set ids are sorted
5. (This is implemented in another function)get the new data entry for tbl_license_flag_set_issued and tbl_license_flag_set_issued_user_conf';


--
-- Name: activity_create_license_flag_set_with_given_contracts(integer[]); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_create_license_flag_set_with_given_contracts(p_contracts integer[]) RETURNS integer[]
    LANGUAGE plpgsql
    AS $$

DECLARE 
    v_lfs_array integer[];
    ret_val integer[];
    i integer;

BEGIN
    
    FOREACH i IN ARRAY p_contracts
    LOOP
        v_lfs_array = array_append(v_lfs_array, (SELECT assist_function_get_last_license_flag_set_defined_to_contract (i)));    
    END LOOP;

    SELECT ARRAY(  
    SELECT DISTINCT license_flag_id FROM tbl_license_flag_set_defined_conf WHERE license_flag_set_defined_id = ANY (SELECT unnest( v_lfs_array))
        ORDER BY 1
    )  
    INTO ret_val
    ;

    RETURN ret_val;
END;

$$;


ALTER FUNCTION public.activity_create_license_flag_set_with_given_contracts(p_contracts integer[]) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_create_license_flag_set_with_given_contracts(p_contracts integer[]); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_create_license_flag_set_with_given_contracts(p_contracts integer[]) IS 'This function returns license flag IDs that defined in given contracts.';


--
-- Name: tblcomputers_id_seq; Type: SEQUENCE; Schema: public; Owner: licenseMgt
--

CREATE SEQUENCE public.tblcomputers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 10000000
    CACHE 1;


ALTER TABLE public.tblcomputers_id_seq OWNER TO "licenseMgt";

--
-- Name: tbl_computers; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_computers (
    id integer DEFAULT nextval('public.tblcomputers_id_seq'::regclass) NOT NULL,
    name character varying(50),
    mac_address character varying(255),
    project_indication character varying(10),
    serial_number bigint,
    blocked boolean DEFAULT false,
    create_date timestamp with time zone,
    memo text,
    inactive boolean DEFAULT false NOT NULL
);


ALTER TABLE public.tbl_computers OWNER TO "licenseMgt";

--
-- Name: activity_find_computer(integer, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_find_computer(p_id integer DEFAULT 0, p_computer_name text DEFAULT ''::text) RETURNS SETOF public.tbl_computers
    LANGUAGE plpgsql
    AS $$

DECLARE
  T text;

BEGIN
  T := p_computer_name;

  IF p_id > 0 THEN
    RETURN QUERY (SELECT * FROM tbl_computers WHERE id = p_id);
  ELSE 
    IF p_computer_name<>'' THEN
      T := '%'|| T || '%';
      RETURN QUERY (SELECT * FROM tbl_computers WHERE name LIKE T);
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION public.activity_find_computer(p_id integer, p_computer_name text) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_find_computer(p_id integer, p_computer_name text); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_find_computer(p_id integer, p_computer_name text) IS '/*
Call with p_id = 0, the function finds record with p_computer_name
Call with p_id = x, the function finds record with ID
*/';


--
-- Name: tblcontracts_id_seq; Type: SEQUENCE; Schema: public; Owner: licenseMgt
--

CREATE SEQUENCE public.tblcontracts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 100000
    CACHE 1;


ALTER TABLE public.tblcontracts_id_seq OWNER TO "licenseMgt";

--
-- Name: tbl_contracts; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_contracts (
    id integer DEFAULT nextval('public.tblcontracts_id_seq'::regclass) NOT NULL,
    title character varying(255),
    description text,
    expiration_date timestamp with time zone,
    user_is_internal boolean DEFAULT false,
    additional_security_required boolean DEFAULT false,
    user_has_conopt boolean DEFAULT false,
    use_default_distribution_channel boolean DEFAULT false,
    create_date timestamp with time zone,
    memo text,
    valid_version character varying(250),
    require_km3dv_license boolean,
    km3dv_licensed_components_text text,
    inactive boolean DEFAULT false NOT NULL
);


ALTER TABLE public.tbl_contracts OWNER TO "licenseMgt";

--
-- Name: COLUMN tbl_contracts.additional_security_required; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_contracts.additional_security_required IS 'specify in description';


--
-- Name: COLUMN tbl_contracts.user_has_conopt; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_contracts.user_has_conopt IS 'CONOPT solver is available to the user.';


--
-- Name: COLUMN tbl_contracts.use_default_distribution_channel; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_contracts.use_default_distribution_channel IS 'Emails are sent to the user as new KRAWAL version is released.';


--
-- Name: COLUMN tbl_contracts.valid_version; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_contracts.valid_version IS 'valid_version defines which version of KRAWAL is agreed to release for a contract

It is in text in form x.xx.xx(x). 

Scenario 1, only a version is agreed to release to the contract, e.g. KM 2.22.2(STC), valid_version=''2.22.2(STC)''

Scenario 2, all release versions after KM 2.xx are available for the contract, valid_version=''2.99.99''

Scenario 3, all release versions even old KM 1.xx are available for the contract, valid_version=''0.0.0''';


--
-- Name: COLUMN tbl_contracts.require_km3dv_license; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_contracts.require_km3dv_license IS 'new field of require 3DV license. The field is enable, 3DV license is necessary for the contract, all users in the contract gets additional license file of Km3dvtool.ini';


--
-- Name: COLUMN tbl_contracts.km3dv_licensed_components_text; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_contracts.km3dv_licensed_components_text IS 'new contract field 3DV licensed components text. The field includes text, which is given by us that defines what steam turbine components are registered for the users in the contract';


--
-- Name: activity_find_contract(integer, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_find_contract(p_id integer DEFAULT 0, p_title text DEFAULT ''::text) RETURNS SETOF public.tbl_contracts
    LANGUAGE plpgsql
    AS $$
DECLARE 
  T text;
BEGIN
  T := p_title;
  IF p_id > 0 THEN
    RETURN QUERY (SELECT * FROM tbl_contracts WHERE id = p_id);
  ELSE 
    IF T<>'' THEN
      T := '%'|| T || '%';
      RETURN QUERY (SELECT * FROM tbl_contracts WHERE title LIKE T);
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION public.activity_find_contract(p_id integer, p_title text) OWNER TO "licenseMgt";

--
-- Name: activity_find_contracts_with_user(integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_find_contracts_with_user(p_user_id integer DEFAULT 0) RETURNS integer[]
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int_array integer[];

BEGIN
    SELECT ARRAY(
    SELECT contract_id FROM tbl_contract_user_conf WHERE user_id = p_user_id)
    INTO v_int_array;

    RETURN v_int_array;
END;

$$;


ALTER FUNCTION public.activity_find_contracts_with_user(p_user_id integer) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_find_contracts_with_user(p_user_id integer); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_find_contracts_with_user(p_user_id integer) IS 'returns contracts'' ids that an user in';


--
-- Name: activity_find_current_license_flag_set_defined_to_contract(integer, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_find_current_license_flag_set_defined_to_contract(p_contract_id integer, p_contract_title text DEFAULT ''::text) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_id integer;
    

BEGIN
    v_id := p_contract_id;
  
    /* if p_computer_id > 0, find issued flagset with latest date, returns issuedID*/
    IF p_contract_id > 0 THEN
        SELECT license_flag_set_defined_id
          FROM view_find_license_flag_set_defined_to_contract
          WHERE contract_id = p_contract_id
          ORDER BY create_date DESC LIMIT 1 INTO v_id;
    ELSE
      IF p_contract_title <> '' THEN
        SELECT id 
          FROM tbl_contracts
          WHERE title = p_contract_title
          ORDER BY id DESC LIMIT 1 INTO v_id;

          IF v_id > 0 THEN
            SELECT license_flag_set_issued_id
              FROM view_find_license_flag_set_issued_to_contract
              WHERE contract_id = v_id
              ORDER BY create_date DESC LIMIT 1 INTO v_id;
          END IF;
          
      END IF;
    END IF;

  RETURN v_id;
END;

$$;


ALTER FUNCTION public.activity_find_current_license_flag_set_defined_to_contract(p_contract_id integer, p_contract_title text) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_find_current_license_flag_set_defined_to_contract(p_contract_id integer, p_contract_title text); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_find_current_license_flag_set_defined_to_contract(p_contract_id integer, p_contract_title text) IS '/*
    This function returns latest license_flag_set_defined to the contract
Call the function with p_contract_id > 0, the function finds a record with contract ID 
Call the function with p_contract_id =0, it is necessary to input contract title as parameter. The function finds record with the contract title.

*/';


--
-- Name: activity_find_current_license_flag_set_issued_to_computer(integer, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_find_current_license_flag_set_issued_to_computer(p_computer_id integer, p_computer_name text DEFAULT ''::text) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_id integer;
    v_title text;

BEGIN
    v_id := p_computer_id;
    v_title := p_computer_name;
  
    /* if p_computer_id > 0, find issued flagset with latest date, returns issuedID*/
    IF v_id > 0 THEN
        SELECT license_flag_set_issued_id
          FROM view_find_license_flag_set_issued_to_computer
          WHERE computer_id = v_id
          ORDER BY create_date DESC LIMIT 1 INTO v_id;
    ELSE
      IF v_title <> '' THEN
        SELECT id 
          FROM tbl_computers
          WHERE name = v_title
          ORDER BY id DESC LIMIT 1 INTO v_id;

          IF v_id > 0 THEN
            SELECT license_flag_set_issued_id
              FROM view_find_license_flag_set_issued_to_computer
              WHERE computer_id = v_id
              ORDER BY create_date DESC LIMIT 1 INTO v_id;
          END IF;
          
      END IF;
    END IF;

  RETURN v_id;
END;
$$;


ALTER FUNCTION public.activity_find_current_license_flag_set_issued_to_computer(p_computer_id integer, p_computer_name text) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_find_current_license_flag_set_issued_to_computer(p_computer_id integer, p_computer_name text); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_find_current_license_flag_set_issued_to_computer(p_computer_id integer, p_computer_name text) IS '/*
Call the function with p_computer_id > 0, the function finds a record with computer ID
Call the function with p_computer_id =0, it is necessary to input computer name as parameter. The function finds record with the computer name.
*/';


--
-- Name: activity_find_current_license_flag_set_issued_to_user(integer, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_find_current_license_flag_set_issued_to_user(p_user_id integer, p_user_email text DEFAULT ''::text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_id integer;
    v_txt text;

BEGIN
    v_id := p_user_id;
    v_txt := p_user_email;
  
    /* if p_user_id > 0, find issued flagset with latest date, returns issuedID*/
    IF v_id > 0 THEN
        SELECT license_flag_set_issued_id
          FROM view_find_license_flag_set_issued_to_user
          WHERE user_id = v_id
          ORDER BY valid_until_date DESC LIMIT 1 INTO v_id;
    ELSE
      IF v_txt <> '' THEN
        SELECT id 
          FROM tbl_users
          WHERE email_address = v_txt
          ORDER BY id DESC LIMIT 1 INTO v_id;

          IF v_id > 0 THEN
            SELECT license_flag_set_issued_id
              FROM view_find_license_flag_set_issued_to_user
              WHERE user_id = v_id
              ORDER BY valid_until_date DESC LIMIT 1 INTO v_id;
          END IF;
          
      END IF;
    END IF;

  RETURN v_id;
END;
$$;


ALTER FUNCTION public.activity_find_current_license_flag_set_issued_to_user(p_user_id integer, p_user_email text) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_find_current_license_flag_set_issued_to_user(p_user_id integer, p_user_email text); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_find_current_license_flag_set_issued_to_user(p_user_id integer, p_user_email text) IS 'Current active license. if there are more than one, the longest one is selected';


--
-- Name: tbllicenseflag_id_seq; Type: SEQUENCE; Schema: public; Owner: licenseMgt
--

CREATE SEQUENCE public.tbllicenseflag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 10000
    CACHE 1;


ALTER TABLE public.tbllicenseflag_id_seq OWNER TO "licenseMgt";

--
-- Name: tbl_license_flag; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_license_flag (
    id integer DEFAULT nextval('public.tbllicenseflag_id_seq'::regclass) NOT NULL,
    title character varying(255),
    title_in_kmsecurity character varying(255),
    description character varying(255),
    memo text,
    external_use_information text,
    internal_use_information text
);


ALTER TABLE public.tbl_license_flag OWNER TO "licenseMgt";

--
-- Name: COLUMN tbl_license_flag.title_in_kmsecurity; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_license_flag.title_in_kmsecurity IS 'KMSecurity is code shared with developing Krawal-Modular as C++ code';


--
-- Name: COLUMN tbl_license_flag.external_use_information; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_license_flag.external_use_information IS 'Explain if this license flag can be given to external user';


--
-- Name: COLUMN tbl_license_flag.internal_use_information; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_license_flag.internal_use_information IS 'Explain if this license flag can be given to a internal user';


--
-- Name: tbllicenseflagsetdefined_id_seq; Type: SEQUENCE; Schema: public; Owner: licenseMgt
--

CREATE SEQUENCE public.tbllicenseflagsetdefined_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 100000000
    CACHE 1;


ALTER TABLE public.tbllicenseflagsetdefined_id_seq OWNER TO "licenseMgt";

--
-- Name: tbl_license_flag_set_defined; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_license_flag_set_defined (
    id integer DEFAULT nextval('public.tbllicenseflagsetdefined_id_seq'::regclass) NOT NULL,
    create_date date,
    memo text
);


ALTER TABLE public.tbl_license_flag_set_defined OWNER TO "licenseMgt";

--
-- Name: view_flag_to_contract; Type: VIEW; Schema: public; Owner: licenseMgt
--

CREATE VIEW public.view_flag_to_contract AS
 SELECT tbl_license_flag.title_in_kmsecurity,
    tbl_license_flag_set_defined_conf.license_flag_id,
    tbl_license_flag_set_defined_contract_conf.contract_id,
    tbl_contracts.title AS contract_title
   FROM public.tbl_license_flag,
    public.tbl_license_flag_set_defined_conf,
    public.tbl_license_flag_set_defined,
    public.tbl_license_flag_set_defined_contract_conf,
    public.tbl_contracts
  WHERE ((tbl_license_flag.id = tbl_license_flag_set_defined_conf.license_flag_id) AND (tbl_license_flag_set_defined_conf.license_flag_set_defined_id = tbl_license_flag_set_defined.id) AND (tbl_license_flag_set_defined.id = tbl_license_flag_set_defined_contract_conf.license_flag_set_defined_id) AND (tbl_license_flag_set_defined_contract_conf.contract_id = tbl_contracts.id))
  ORDER BY tbl_license_flag.title;


ALTER TABLE public.view_flag_to_contract OWNER TO "licenseMgt";

--
-- Name: activity_find_license_flag_to_contracts(integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_find_license_flag_to_contracts(p_id integer) RETURNS SETOF public.view_flag_to_contract
    LANGUAGE plpgsql
    AS $$
BEGIN

  RETURN QUERY SELECT 
    title,	
    license_flag_id, 
    contract_id,
    contract_title
  FROM view_flag_to_contract
  WHERE license_flag_id = p_id;
  RETURN;

END;
$$;


ALTER FUNCTION public.activity_find_license_flag_to_contracts(p_id integer) OWNER TO "licenseMgt";

--
-- Name: activity_find_license_flag_to_contracts(text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_find_license_flag_to_contracts(p_title text) RETURNS SETOF public.view_flag_to_contract
    LANGUAGE plpgsql
    AS $$
BEGIN

  RETURN QUERY SELECT 
    title,	
    license_flag_id, 
    contract_id,
    contract_title
  FROM view_flag_to_contract
  WHERE title = p_title;
  RETURN;

END;
$$;


ALTER FUNCTION public.activity_find_license_flag_to_contracts(p_title text) OWNER TO "licenseMgt";

--
-- Name: tbllicenseflagsetissued_id_seq; Type: SEQUENCE; Schema: public; Owner: licenseMgt
--

CREATE SEQUENCE public.tbllicenseflagsetissued_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 100000000
    CACHE 1;


ALTER TABLE public.tbllicenseflagsetissued_id_seq OWNER TO "licenseMgt";

--
-- Name: tbl_license_flag_set_issued; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_license_flag_set_issued (
    id integer DEFAULT nextval('public.tbllicenseflagsetissued_id_seq'::regclass) NOT NULL,
    valid_until_date timestamp with time zone,
    valid_version character varying(255),
    create_date timestamp with time zone,
    memo text
);


ALTER TABLE public.tbl_license_flag_set_issued OWNER TO "licenseMgt";

--
-- Name: COLUMN tbl_license_flag_set_issued.valid_version; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_license_flag_set_issued.valid_version IS 'This column is mirrored from tbl_contracts.';


--
-- Name: tblusers_id_seq; Type: SEQUENCE; Schema: public; Owner: licenseMgt
--

CREATE SEQUENCE public.tblusers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 10000000
    CACHE 1;


ALTER TABLE public.tblusers_id_seq OWNER TO "licenseMgt";

--
-- Name: tbl_users; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_users (
    id integer DEFAULT nextval('public.tblusers_id_seq'::regclass) NOT NULL,
    last_name character varying(50),
    first_name character varying(50),
    logon_name character varying(8),
    email_address character varying(80),
    gid_number character varying(255),
    blocked boolean DEFAULT false,
    create_date timestamp with time zone,
    memo text,
    inactive boolean DEFAULT false NOT NULL
);


ALTER TABLE public.tbl_users OWNER TO "licenseMgt";

--
-- Name: COLUMN tbl_users.gid_number; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_users.gid_number IS 'GID - Personal Global ID number';


--
-- Name: view_flag_to_user; Type: VIEW; Schema: public; Owner: licenseMgt
--

CREATE VIEW public.view_flag_to_user AS
 SELECT tbl_license_flag.title_in_kmsecurity AS title,
    tbl_users.id,
    tbl_users.last_name,
    tbl_users.first_name,
    tbl_users.email_address
   FROM public.tbl_license_flag,
    public.tbl_license_flag_set_issued_conf,
    public.tbl_license_flag_set_issued,
    public.tbl_license_flag_set_issued_user_conf,
    public.tbl_users
  WHERE ((tbl_license_flag.id = tbl_license_flag_set_issued_conf.license_flag_id) AND (tbl_license_flag_set_issued_conf.license_flag_set_issued_id = tbl_license_flag_set_issued.id) AND (tbl_license_flag_set_issued.id = tbl_license_flag_set_issued_user_conf.license_flag_set_issued_id) AND (tbl_license_flag_set_issued_user_conf.user_id = tbl_users.id));


ALTER TABLE public.view_flag_to_user OWNER TO "licenseMgt";

--
-- Name: activity_find_license_flag_to_users(text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_find_license_flag_to_users(p_flag_title text) RETURNS SETOF public.view_flag_to_user
    LANGUAGE plpgsql
    AS $$BEGIN
  RETURN QUERY SELECT 
  title, id, last_name, first_name, email_address
    FROM view_flag_to_user
    WHERE title = p_flag_title; -- result is forwarded to output directly
  RETURN;   -- there will not be any next result, finish execution
END;$$;


ALTER FUNCTION public.activity_find_license_flag_to_users(p_flag_title text) OWNER TO "licenseMgt";

--
-- Name: activity_find_user(integer, text, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_find_user(p_id integer DEFAULT 0, p_email text DEFAULT ''::text, p_name text DEFAULT ''::text) RETURNS SETOF public.tbl_users
    LANGUAGE plpgsql
    AS $$
DECLARE 
  T text;
  v_name text;
BEGIN
  T := p_email;
  v_name := p_name;
  IF p_id > 0 THEN
    RETURN QUERY (SELECT * FROM tbl_users WHERE id = p_id);
  ELSE 
    IF T<>'' THEN
      T := '%'|| T || '%';
      RETURN QUERY (SELECT * FROM tbl_users WHERE email_address LIKE T);
    ELSE
      IF v_name <>'' THEN
        v_name := '%'|| v_name || '%';
        RETURN QUERY (SELECT * FROM tbl_users WHERE last_name LIKE v_name);
      END IF;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION public.activity_find_user(p_id integer, p_email text, p_name text) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_find_user(p_id integer, p_email text, p_name text); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_find_user(p_id integer, p_email text, p_name text) IS '/*
Call the activity with p_id = x, an user is found with his ID if the ID exists and equals x,
call the activity with p_id = 0, email address of the user is the parameter to find the record,
call the activity with p_id = 0 and p_email = '''', last name of the user(s) is the parameter with which to find recor(s)
*/';


--
-- Name: activity_get_valid_date_from_contracts_of_user(integer, boolean); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_get_valid_date_from_contracts_of_user(p_user_id integer, p_exact_date boolean DEFAULT false) RETURNS date
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_contracts integer[];
    ret_val date;

BEGIN

    SELECT activity_find_contracts_with_user(p_user_id) 
    INTO v_contracts;    
    
    SELECT 
       assist_function_get_valid_until_date_with_contracts(v_contracts, p_exact_date)
    INTO ret_val;

    RETURN ret_val;
END;

$$;


ALTER FUNCTION public.activity_get_valid_date_from_contracts_of_user(p_user_id integer, p_exact_date boolean) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_get_valid_date_from_contracts_of_user(p_user_id integer, p_exact_date boolean); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_get_valid_date_from_contracts_of_user(p_user_id integer, p_exact_date boolean) IS 'All expiration_date in all contracts of the user are listed. the longest date is taken as new valid_date for the user as a license_flag_set being issued to him.
    The valid_until_date is maximum 1 year
    ';


--
-- Name: activity_is_user_active(integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_is_user_active(p_user_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_id integer;
    v_days integer;
    v_valid_until_date TIMESTAMP;

BEGIN
    v_id := p_user_id;
    IF v_id > 0 THEN
      SELECT activity_find_current_license_flag_set_issued_to_user(v_id) INTO v_id;

      IF v_id > 0 THEN -- if issued ID exists

	SELECT assist_function_license_valid_days(v_id) INTO v_days;

	IF v_days > 0 THEN -- if valid longer than 0 days
	  RETURN TRUE;
	END IF;

      END IF;
    END IF;

  RETURN FALSE;
END;
$$;


ALTER FUNCTION public.activity_is_user_active(p_user_id integer) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_is_user_active(p_user_id integer); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_is_user_active(p_user_id integer) IS '/*
The function returs TRUE, if current license flag set issued to the user exists and valid longer than 30 days. Otherwise, returns FALSE
*/';


--
-- Name: activity_is_user_external(integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_is_user_external(p_user_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_bool boolean;

BEGIN

    v_bool := FALSE;
    
    /* if p_user_id > 0, find issued flagset with latest date, returns issuedID*/
    IF p_user_id > 0 THEN
        SELECT user_is_internal
          FROM view_find_contract_the_user_belongs_to
          WHERE user_id = p_user_id
          INTO v_bool;
    END IF;

  RETURN v_bool;
END;
$$;


ALTER FUNCTION public.activity_is_user_external(p_user_id integer) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_is_user_external(p_user_id integer); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_is_user_external(p_user_id integer) IS '/*
The function returns TRUE only if the user exists and is in a external contract.
*/';


--
-- Name: activity_remove_duplicate_tbl_license_flag_set_conf(); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_remove_duplicate_tbl_license_flag_set_conf() RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_message text;
BEGIN
  v_message := 'rows affected.';
  
  DELETE FROM tbl_license_flag_set_conf WHERE ctid NOT IN
  (SELECT max(ctid)
   FROM tbl_license_flag_set_conf
   GROUP BY tbl_license_flag_set_conf.*);
 
  RETURN v_message;
END;
$$;


ALTER FUNCTION public.activity_remove_duplicate_tbl_license_flag_set_conf() OWNER TO "licenseMgt";

--
-- Name: activity_update_tbl_computers(integer, text, text, text, bigint, boolean, text, boolean); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_update_tbl_computers(p_id integer, p_name text, p_mac text, p_pkz text, p_serialnumber bigint, p_blocked boolean, p_memo text, p_inactive boolean DEFAULT false) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int integer;
    v_created_date timestamp with time zone;

BEGIN
    v_int := 0;
    v_created_date := now();

  
  IF p_id > 0 THEN
    v_int := p_id;
    UPDATE tbl_computers
      SET (name, mac_address,project_indication, serial_number, blocked, memo, inactive) 
        = (p_name, p_mac,p_pkz, p_serialNumber,p_blocked, p_memo, p_inactive)
      WHERE id = p_id;
  ELSE    
    INSERT INTO tbl_computers(name, mac_address,project_indication, serial_number, blocked,memo, create_date)
                        VALUES(p_name, p_mac,p_pkz, p_serialNumber,p_blocked, p_memo, v_created_date);

    SELECT last_value FROM tblcomputers_id_seq INTO v_int;
  END IF;

  RETURN v_int;
END;

$$;


ALTER FUNCTION public.activity_update_tbl_computers(p_id integer, p_name text, p_mac text, p_pkz text, p_serialnumber bigint, p_blocked boolean, p_memo text, p_inactive boolean) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_update_tbl_computers(p_id integer, p_name text, p_mac text, p_pkz text, p_serialnumber bigint, p_blocked boolean, p_memo text, p_inactive boolean); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_update_tbl_computers(p_id integer, p_name text, p_mac text, p_pkz text, p_serialnumber bigint, p_blocked boolean, p_memo text, p_inactive boolean) IS '
/*
To add new computer, call the function with p_id=0, then input other information of the computer. Field inactive must be false for new computer
*/';


--
-- Name: activity_update_tbl_contact_person(integer, text, text, text, text, text, boolean); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_update_tbl_contact_person(p_id integer, p_lastname text, p_firstname text, p_email text, p_gid text, p_memo text, p_inactive boolean DEFAULT false) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
  v_int integer;

BEGIN
  
  IF p_id > 0 THEN
    UPDATE tbl_contact_person
      SET (last_name,  first_name,  e_mail,  gid_number,  memo, inactive) 
        = (p_lastname ,  p_firstname, p_email , p_gid , p_memo, p_inactive)
      WHERE id = p_id;
    v_int := p_id;
  ELSE    
    INSERT INTO tbl_contact_person(last_name,  first_name, e_mail,  gid_number, create_date,  memo ) 
                            VALUES(p_lastname,  p_firstname, p_email , p_gid , now(),  p_memo);
    SELECT last_value FROM tblcontactperson_id_seq INTO v_int;
  END IF;

  RETURN v_int;
END;
$$;


ALTER FUNCTION public.activity_update_tbl_contact_person(p_id integer, p_lastname text, p_firstname text, p_email text, p_gid text, p_memo text, p_inactive boolean) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_update_tbl_contact_person(p_id integer, p_lastname text, p_firstname text, p_email text, p_gid text, p_memo text, p_inactive boolean); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_update_tbl_contact_person(p_id integer, p_lastname text, p_firstname text, p_email text, p_gid text, p_memo text, p_inactive boolean) IS '/*
Call the function with ID=0, means to append a new record.
Call the function with ID=x, means update the record that its ID is x.
*/';


--
-- Name: activity_update_tbl_contracts(integer, text, text, timestamp with time zone, boolean, boolean, boolean, boolean, text, boolean, text, text, boolean); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_update_tbl_contracts(p_id integer, p_title text, p_description text, p_expiration_date timestamp with time zone, p_user_is_internal boolean, p_additional_security_required boolean, p_user_has_conopt boolean, p_user_send_update_mails boolean, p_valid_version text, p_require_km3dv_license boolean, p_km3dv_licensed_components_text text, p_memo text, p_inactive boolean DEFAULT false) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int integer;

BEGIN
  
  IF p_id > 0 THEN
    UPDATE tbl_contracts
      SET (title, description, expiration_date, user_is_internal, additional_security_required, require_km3dv_license, km3dv_licensed_components_text,  
           user_has_conopt,  use_default_distribution_channel,  valid_version, memo, inactive) 
        = (p_title,  p_description, p_expiration_date, p_user_is_internal, p_additional_security_required, p_require_km3dv_license, p_km3dv_licensed_components_text,
	  p_user_has_conopt, p_user_send_update_mails, p_valid_version, p_memo, p_inactive)
      WHERE id = p_id;
    v_int := p_id;
  ELSE    
    INSERT INTO tbl_contracts(title,  description,  expiration_date,  user_is_internal,  additional_security_required, require_km3dv_license, km3dv_licensed_components_text, 
				user_has_conopt,  use_default_distribution_channel, create_date, valid_version,  memo) 
                       VALUES(p_title,  p_description, p_expiration_date, p_user_is_internal, p_additional_security_required, p_require_km3dv_license, p_km3dv_licensed_components_text,
				p_user_has_conopt, p_user_send_update_mails, now(), p_valid_version, p_memo);
    SELECT last_value FROM tblcontracts_id_seq INTO v_int;
  END IF;
  
  RETURN v_int;
END;

$$;


ALTER FUNCTION public.activity_update_tbl_contracts(p_id integer, p_title text, p_description text, p_expiration_date timestamp with time zone, p_user_is_internal boolean, p_additional_security_required boolean, p_user_has_conopt boolean, p_user_send_update_mails boolean, p_valid_version text, p_require_km3dv_license boolean, p_km3dv_licensed_components_text text, p_memo text, p_inactive boolean) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_update_tbl_contracts(p_id integer, p_title text, p_description text, p_expiration_date timestamp with time zone, p_user_is_internal boolean, p_additional_security_required boolean, p_user_has_conopt boolean, p_user_send_update_mails boolean, p_valid_version text, p_require_km3dv_license boolean, p_km3dv_licensed_components_text text, p_memo text, p_inactive boolean); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_update_tbl_contracts(p_id integer, p_title text, p_description text, p_expiration_date timestamp with time zone, p_user_is_internal boolean, p_additional_security_required boolean, p_user_has_conopt boolean, p_user_send_update_mails boolean, p_valid_version text, p_require_km3dv_license boolean, p_km3dv_licensed_components_text text, p_memo text, p_inactive boolean) IS 'This function updates a row in tbl_contracts. 
Parameter p_inactive is set to false as default. The function can be called without p_inactive ';


--
-- Name: activity_update_tbl_license_flag(integer, text, text, text, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_update_tbl_license_flag(p_id integer, p_title text, p_km_security_title text, p_description text, p_memo text) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int integer;

BEGIN
  
  IF p_id > 0 THEN
    UPDATE tbl_license_flag
      SET (title,  title_in_kmsecurity,  description, memo) 
        = (p_title ,  p_km_security_title, p_description , p_memo)
      WHERE id = p_id;
    v_int := p_id;
  ELSE    
    INSERT INTO tbl_license_flag(title,  title_in_kmsecurity,  description, memo) 
                        VALUES(p_title ,  p_km_security_title, p_description , p_memo);
    SELECT last_value FROM tbllicenseflag_id_seq INTO v_int;
  END IF;

  RETURN v_int;
END;
$$;


ALTER FUNCTION public.activity_update_tbl_license_flag(p_id integer, p_title text, p_km_security_title text, p_description text, p_memo text) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_update_tbl_license_flag(p_id integer, p_title text, p_km_security_title text, p_description text, p_memo text); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_update_tbl_license_flag(p_id integer, p_title text, p_km_security_title text, p_description text, p_memo text) IS '/*
Call the function with ID=0, means to append a new record.
Call the function with ID=x, means update the record that its ID is x.
*/';


--
-- Name: activity_update_tbl_license_flag(integer, text, text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_update_tbl_license_flag(p_id integer, p_title text, p_km_security_title text, p_description text, p_internal_use_information text, p_external_use_information text, p_memo text) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int integer;

BEGIN
  
  IF p_id > 0 THEN
    UPDATE tbl_license_flag
      SET (title,  title_in_kmsecurity,  description,internal_use_information, external_use_information, memo) 
        = (p_title ,  p_km_security_title, p_description ,p_internal_use_information, p_external_use_information, p_memo)
      WHERE id = p_id;
    v_int := p_id;
  ELSE    
    INSERT INTO tbl_license_flag(title,  title_in_kmsecurity, description, internal_use_information, external_use_information, memo) 
                        VALUES(p_title ,  p_km_security_title, p_description,p_internal_use_information, p_external_use_information, p_memo);
    SELECT last_value FROM tbllicenseflag_id_seq INTO v_int;
  END IF;

  RETURN v_int;
END;

$$;


ALTER FUNCTION public.activity_update_tbl_license_flag(p_id integer, p_title text, p_km_security_title text, p_description text, p_internal_use_information text, p_external_use_information text, p_memo text) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_update_tbl_license_flag(p_id integer, p_title text, p_km_security_title text, p_description text, p_internal_use_information text, p_external_use_information text, p_memo text); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_update_tbl_license_flag(p_id integer, p_title text, p_km_security_title text, p_description text, p_internal_use_information text, p_external_use_information text, p_memo text) IS '* This function is for adding and updating an entry in tbl_license_flag

* To add an entry:
   call the function with parameters:
     i. p_id = 0
     ii. from p_title to  p_memo one by one
     iii. p_km_security_title must be copied from Krawal-modular, 
     iv. an assist function returns a list of existing license flag titles in Krawal-modular, new entry must be different to any of in the list.

* To modify an entry:
  call the function with parameters:
  i. p_id > 0, it is for the entry which is to be changed
  ii. p_km_security_title does not have effect, it won''t change column title_in_kmsecurity. 

* column title_in_kmsecurity is synchronized with Krawal-modular.
  1. If there is a new entry in Krawal-modular, the new entry is added to the column.
  2. After adding a new entry in the column, it won''t be changed any more.';


--
-- Name: activity_update_tbl_license_flag_set_conf(integer, integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_update_tbl_license_flag_set_conf(p_license_flag_set_issued_id integer, p_license_flag_id integer) RETURNS public.tbl_license_flag_set_issued_conf
    LANGUAGE sql
    AS $$

INSERT INTO tbl_license_flag_set_issued_conf (license_flag_set_issued_id, license_flag_id)
(
    SELECT p_license_flag_set_issued_id, p_license_flag_id
)
RETURNING license_flag_set_issued_id, license_flag_id

$$;


ALTER FUNCTION public.activity_update_tbl_license_flag_set_conf(p_license_flag_set_issued_id integer, p_license_flag_id integer) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_update_tbl_license_flag_set_conf(p_license_flag_set_issued_id integer, p_license_flag_id integer); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_update_tbl_license_flag_set_conf(p_license_flag_set_issued_id integer, p_license_flag_id integer) IS '/*
Parameters: ("LicenseFlagSetIssuedID", "LicenseFlagID")
Returns: Table is updated.
Note: no duplicate is allowed.
*/';


--
-- Name: activity_update_tbl_license_flag_set_issued(timestamp with time zone, text, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_update_tbl_license_flag_set_issued(p_valid_until_date timestamp with time zone, p_memo text, p_valid_version text DEFAULT '2.99.99'::text) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
  v_id integer;
  v_created_date timestamp with time zone;

BEGIN
  v_created_date := now();
      
  INSERT INTO tbl_license_flag_set_issued(valid_until_date, valid_version, create_date,memo)
				VALUES(p_valid_until_date, p_valid_version, v_created_date, p_memo);
  SELECT last_value FROM tbllicenseflagsetissued_id_seq INTO v_id;
  
  RETURN v_id;
END;
$$;


ALTER FUNCTION public.activity_update_tbl_license_flag_set_issued(p_valid_until_date timestamp with time zone, p_memo text, p_valid_version text) OWNER TO "licenseMgt";

--
-- Name: FUNCTION activity_update_tbl_license_flag_set_issued(p_valid_until_date timestamp with time zone, p_memo text, p_valid_version text); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.activity_update_tbl_license_flag_set_issued(p_valid_until_date timestamp with time zone, p_memo text, p_valid_version text) IS '/*
This function adds a new record in the table.
*/';


--
-- Name: activity_update_tbl_users(integer, text, text, text, text, text, boolean, text, boolean); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.activity_update_tbl_users(p_id integer, p_lastname text, p_firstname text, p_logonname text, p_email text, p_gid text, p_blocked boolean, p_memo text, p_inactive boolean DEFAULT false) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int integer;

BEGIN
  
  IF p_id > 0 THEN

    UPDATE tbl_users
      SET (last_name, first_name, logon_name, email_address, gid_number,  blocked, memo, inactive) 
        = (p_lastname, p_firstname, p_logonname, p_email,        p_gid,  p_blocked, p_memo, p_inactive)
      WHERE id = p_id;
    v_int := p_id;  
    
  ELSE    
 
    INSERT INTO tbl_users(last_name, first_name, logon_name, email_address, gid_number,  blocked, create_date, memo) 
                    VALUES(p_lastname , p_firstname, p_logonname, p_email,        p_gid,  p_blocked,  now(),       p_memo);
    SELECT last_value FROM tblusers_id_seq INTO v_int;

  END IF;

  RETURN v_int;
END;
$$;


ALTER FUNCTION public.activity_update_tbl_users(p_id integer, p_lastname text, p_firstname text, p_logonname text, p_email text, p_gid text, p_blocked boolean, p_memo text, p_inactive boolean) OWNER TO "licenseMgt";

--
-- Name: assist_function_assign_license_flag_set_to_tbl_issued_with_int_(integer, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_assign_license_flag_set_to_tbl_issued_with_int_(p_license_flag_set_issued_id integer, p_text text) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int integer;
    v_txt_array text[];
    v_int_array integer[];


BEGIN

    /* split text into license flags */
    SELECT String_To_Array(p_text,' ') INTO v_txt_array;

    FOR i IN 1..Array_Length(v_txt_array,1)
    LOOP
      SELECT id FROM tbl_license_flag WHERE title_in_kmsecurity = v_txt_array[i] INTO v_int;
      IF v_int > 0 THEN
          PERFORM activity_update_tbl_license_flag_set_conf(p_license_flag_set_issued_id, v_int);
      END IF;
    END LOOP;   

  RETURN v_int;
END;
$$;


ALTER FUNCTION public.assist_function_assign_license_flag_set_to_tbl_issued_with_int_(p_license_flag_set_issued_id integer, p_text text) OWNER TO "licenseMgt";

--
-- Name: FUNCTION assist_function_assign_license_flag_set_to_tbl_issued_with_int_(p_license_flag_set_issued_id integer, p_text text); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.assist_function_assign_license_flag_set_to_tbl_issued_with_int_(p_license_flag_set_issued_id integer, p_text text) IS 'The input string is set of license flag names (tbl_license_flag.title_in_kmsecurity)
This function converts input string in an array of flag ids. The flag-id-array is assigned to license-flag-set-issued-id one by one.';


--
-- Name: assist_function_delete_records(text, text, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_delete_records(p_table text, p_column text, p_filter text) RETURNS integer
    LANGUAGE plpgsql
    AS $$

BEGIN
    DELETE FROM p_table WHERE p_column = p_filter;  

  RETURN 0;
END;
$$;


ALTER FUNCTION public.assist_function_delete_records(p_table text, p_column text, p_filter text) OWNER TO "licenseMgt";

--
-- Name: assist_function_get_disable_flag_ids(integer[]); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_get_disable_flag_ids(p_enable_license_flag_ids integer[]) RETURNS integer[]
    LANGUAGE plpgsql
    AS $$

DECLARE
  ret integer[];

BEGIN

  SELECT ARRAY(
  SELECT DISTINCT id FROM tbl_license_flag 
  WHERE id NOT IN (SELECT unnest(p_enable_license_flag_ids))
      ORDER BY id
  )
  into ret;

  RETURN ret;
END;

$$;


ALTER FUNCTION public.assist_function_get_disable_flag_ids(p_enable_license_flag_ids integer[]) OWNER TO "licenseMgt";

--
-- Name: FUNCTION assist_function_get_disable_flag_ids(p_enable_license_flag_ids integer[]); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.assist_function_get_disable_flag_ids(p_enable_license_flag_ids integer[]) IS 'This function returns array of license-flag-ids that are other than input ids. Input is array of ids of enable flags.
The disable license flag ids are needed for calling ConsoleLicenser';


--
-- Name: assist_function_get_last_license_flag_set_defined_to_contract(integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_get_last_license_flag_set_defined_to_contract(p_contract_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_ids_lfs_defined integer[];
    ret_int integer;

BEGIN
    SELECT ARRAY(
	SELECT license_flag_set_defined_id FROM tbl_license_flag_set_defined_contract_conf WHERE contract_id = p_contract_id
    )
    INTO v_ids_lfs_defined;

	SELECT id FROM tbl_license_flag_set_defined WHERE id = ANY (SELECT unnest(v_ids_lfs_defined))
    ORDER BY id DESC
    LIMIT 1
    INTO ret_int;
    
    IF ret_int > 0 THEN
        return ret_int;
    ELSE
        return 0;
    END IF;
END;

$$;


ALTER FUNCTION public.assist_function_get_last_license_flag_set_defined_to_contract(p_contract_id integer) OWNER TO "licenseMgt";

--
-- Name: FUNCTION assist_function_get_last_license_flag_set_defined_to_contract(p_contract_id integer); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.assist_function_get_last_license_flag_set_defined_to_contract(p_contract_id integer) IS 'take only latest defined lfs for the contract';


--
-- Name: assist_function_get_later_valid_version(text, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_get_later_valid_version(p_valid_v1 text DEFAULT ''::text, p_valid_v2 text DEFAULT ''::text) RETURNS text
    LANGUAGE plpgsql
    AS $$

DECLARE
  valid_v1 text[];
  valid_v2 text[];
  no_limit_v text;

  ret text;

BEGIN
  valid_v1 = string_to_array(p_valid_v1,'.');
  valid_v2 = string_to_array(p_valid_v2,'.');
  
  no_limit_v = '0.0.0';

  IF valid_v1 <> string_to_array(no_limit_v,'.') THEN	
    IF valid_v2 <> string_to_array(no_limit_v,'.') THEN	
      IF valid_v1 > valid_v2 THEN	
        ret = p_valid_v1;
      ELSE
        ret = p_valid_v2;
      END IF;
    ELSE
      ret = p_valid_v2;
    END IF;
  ELSE
    ret = p_valid_v1;
  END IF;
  
  RETURN ret;
END;

$$;


ALTER FUNCTION public.assist_function_get_later_valid_version(p_valid_v1 text, p_valid_v2 text) OWNER TO "licenseMgt";

--
-- Name: FUNCTION assist_function_get_later_valid_version(p_valid_v1 text, p_valid_v2 text); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.assist_function_get_later_valid_version(p_valid_v1 text, p_valid_v2 text) IS 'This function compare two valid version and returns the later one back. e.g. 2.22.3 compared to 2.23.1, return 2.23.1 because it is later version. This function is used if lfs-issued to an user who is in more than one contracts';


--
-- Name: assist_function_get_license_flags_as_array_by_reading_tbl_li(); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_get_license_flags_as_array_by_reading_tbl_li() RETURNS text[]
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_txt_array text[];

BEGIN
   
  SELECT ARRAY(SELECT title_in_kmsecurity FROM tbl_license_flag ORDER BY title_in_kmsecurity) into v_txt_array;
  
  RETURN v_txt_array;
END;

$$;


ALTER FUNCTION public.assist_function_get_license_flags_as_array_by_reading_tbl_li() OWNER TO "licenseMgt";

--
-- Name: assist_function_get_new_coming_id_in_a_table(text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_get_new_coming_id_in_a_table(p_table_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_id integer;
BEGIN

  SELECT currval('"tblcomputers_id_seq"') INTO v_id;
  RETURN v_id;
  
END;$$;


ALTER FUNCTION public.assist_function_get_new_coming_id_in_a_table(p_table_name text) OWNER TO "licenseMgt";

--
-- Name: assist_function_get_oldest_valid_version_in_contracts(integer[]); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_get_oldest_valid_version_in_contracts(p_contracts integer[]) RETURNS text
    LANGUAGE plpgsql
    AS $$

DECLARE
  ret text;

BEGIN

  SELECT title FROM tbl_contracts
  WHERE id = ANY(SELECT unnest(p_contracts))
  ORDER BY title DESC
  LIMIT 1
  
  INTO ret;

  RETURN ret;
  
END;

$$;


ALTER FUNCTION public.assist_function_get_oldest_valid_version_in_contracts(p_contracts integer[]) OWNER TO "licenseMgt";

--
-- Name: FUNCTION assist_function_get_oldest_valid_version_in_contracts(p_contracts integer[]); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.assist_function_get_oldest_valid_version_in_contracts(p_contracts integer[]) IS 'Input integer array of Contract IDs';


--
-- Name: assist_function_get_valid_until_date_with_contracts(integer[], boolean); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_get_valid_until_date_with_contracts(p_contracts integer[], p_exact_date boolean DEFAULT false) RETURNS date
    LANGUAGE plpgsql
    AS $$

DECLARE
  ret date;

BEGIN
    SELECT 
       CASE 
         WHEN p_exact_date = 't' THEN expiration_date::date
         WHEN expiration_date > now() + interval '1 year' THEN (now() + interval '1 year')::date
         WHEN expiration_date > now() THEN expiration_date::date
       END
    FROM tbl_contracts 
    
    WHERE id = ANY(SELECT unnest(p_contracts))
    ORDER BY expiration_date ASC
    limit 1
    
    INTO ret;

	IF ret < now() THEN
	  RETURN null;
	END IF;

    RETURN ret;
END;

$$;


ALTER FUNCTION public.assist_function_get_valid_until_date_with_contracts(p_contracts integer[], p_exact_date boolean) OWNER TO "licenseMgt";

--
-- Name: FUNCTION assist_function_get_valid_until_date_with_contracts(p_contracts integer[], p_exact_date boolean); Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON FUNCTION public.assist_function_get_valid_until_date_with_contracts(p_contracts integer[], p_exact_date boolean) IS 'If all contracts have expiration_date longer than 1 year, returns 1 year.
If some expiration_dates are shorter than 1 year, returns the shortest one.
If one of the contracts is expired, return null';


--
-- Name: assist_function_license_valid_days(integer); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_license_valid_days(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_days integer;
    v_valid_until_date TIMESTAMP;

BEGIN

      SELECT valid_until_date FROM tbl_license_flag_set_issued
        WHERE id = p_id
        INTO v_valid_until_date;

      SELECT date_part('day', v_valid_until_date - now()) INTO v_days;

  RETURN v_days;
END;
$$;


ALTER FUNCTION public.assist_function_license_valid_days(p_id integer) OWNER TO "licenseMgt";

--
-- Name: assist_function_update_table_in_column_with_value(integer, text, text, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_update_table_in_column_with_value(p_id integer, p_table text, p_column text, p_value timestamp without time zone) RETURNS text
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int integer;
    v_text text;

BEGIN
    SELECT table_name FROM information_schema.tables WHERE table_name = p_table INTO v_text;
    SELECT last_name FROM v_text WHERE id = p_id INTO v_text;
   /* 
    UPDATE p_table
      SET (p_column) 
        = (p_value)*/
      --SELECT id FROM p_table INTO v_int;  
     -- WHERE id = p_id;
    --v_int := p_id;

  RETURN v_text;
END;
$$;


ALTER FUNCTION public.assist_function_update_table_in_column_with_value(p_id integer, p_table text, p_column text, p_value timestamp without time zone) OWNER TO "licenseMgt";

--
-- Name: assist_function_update_table_in_field_with_value(integer, text, text, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_update_table_in_field_with_value(p_id integer, p_table text, p_column text, p_value timestamp without time zone) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int integer;

BEGIN
   /* 
    UPDATE p_table
      SET (p_column) 
        = (p_value)*/
      SELECT id FROM p_table INTO v_int;  
     -- WHERE id = p_id;
    --v_int := p_id;

  RETURN v_int;
END;
$$;


ALTER FUNCTION public.assist_function_update_table_in_field_with_value(p_id integer, p_table text, p_column text, p_value timestamp without time zone) OWNER TO "licenseMgt";

--
-- Name: assist_function_with_int_and_text(integer, text, text); Type: FUNCTION; Schema: public; Owner: licenseMgt
--

CREATE FUNCTION public.assist_function_with_int_and_text(p_license_flag_set_id integer, p_text text, p_table text) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_int integer;
    v_txt_array text[];
    v_int_array integer[];

BEGIN

    /* split text into license flags */
    SELECT String_To_Array(p_text,' ') INTO v_txt_array;

    FOR i IN 1..Array_Length(v_txt_array,1)
    LOOP
      SELECT id FROM tbl_license_flag WHERE title_in_kmsecurity = v_txt_array[i] INTO v_int;
      IF v_int > 0 THEN
        if  p_table = 'defined' THEN
          PERFORM activity_assign_license_flag_to_license_flag_set_defined(p_license_flag_set_id, v_int);        
        ELSE
          PERFORM activity_assign_license_flag_to_license_flag_set_issued(p_license_flag_set_id, v_int);
        END IF;
      END IF;
    END LOOP;   

  RETURN v_int;
END;

$$;


ALTER FUNCTION public.assist_function_with_int_and_text(p_license_flag_set_id integer, p_text text, p_table text) OWNER TO "licenseMgt";

--
-- Name: tbladmin_id_seq; Type: SEQUENCE; Schema: public; Owner: licenseMgt
--

CREATE SEQUENCE public.tbladmin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbladmin_id_seq OWNER TO "licenseMgt";

--
-- Name: SEQUENCE tbladmin_id_seq; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON SEQUENCE public.tbladmin_id_seq IS 'Nextval 1';


--
-- Name: tbl_admin; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_admin (
    id integer DEFAULT nextval('public.tbladmin_id_seq'::regclass) NOT NULL,
    logon character varying(25),
    password character varying(16)
);


ALTER TABLE public.tbl_admin OWNER TO "licenseMgt";

--
-- Name: tblcontactperson_id_seq; Type: SEQUENCE; Schema: public; Owner: licenseMgt
--

CREATE SEQUENCE public.tblcontactperson_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 100000
    CACHE 1;


ALTER TABLE public.tblcontactperson_id_seq OWNER TO "licenseMgt";

--
-- Name: tbl_contact_person; Type: TABLE; Schema: public; Owner: licenseMgt
--

CREATE TABLE public.tbl_contact_person (
    id integer DEFAULT nextval('public.tblcontactperson_id_seq'::regclass) NOT NULL,
    last_name character varying(255),
    first_name character varying(255),
    e_mail character varying(255),
    gid_number character varying(255),
    create_date timestamp with time zone,
    memo text,
    inactive boolean DEFAULT false NOT NULL
);


ALTER TABLE public.tbl_contact_person OWNER TO "licenseMgt";

--
-- Name: COLUMN tbl_contact_person.gid_number; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON COLUMN public.tbl_contact_person.gid_number IS 'GID - Personal Global ID number';


--
-- Name: view_computers_with_users; Type: VIEW; Schema: public; Owner: licenseMgt
--

CREATE VIEW public.view_computers_with_users AS
 SELECT tbl_computers.name,
    tbl_users.last_name,
    tbl_users.email_address
   FROM public.tbl_computers,
    public.tbl_user_computer_conf,
    public.tbl_users
  WHERE ((tbl_user_computer_conf.user_id = tbl_users.id) AND (tbl_user_computer_conf.computer_id = tbl_computers.id))
  ORDER BY tbl_users.email_address;


ALTER TABLE public.view_computers_with_users OWNER TO "licenseMgt";

--
-- Name: VIEW view_computers_with_users; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON VIEW public.view_computers_with_users IS 'list computers with assigned users';


--
-- Name: view_find_contract_the_user_belongs_to; Type: VIEW; Schema: public; Owner: licenseMgt
--

CREATE VIEW public.view_find_contract_the_user_belongs_to AS
 SELECT tbl_contract_user_conf.user_id,
    tbl_users.last_name,
    tbl_users.email_address,
    tbl_contract_user_conf.contract_id,
    tbl_contracts.title,
    tbl_contracts.user_is_internal
   FROM public.tbl_users,
    public.tbl_contracts,
    public.tbl_contract_user_conf
  WHERE ((tbl_users.id = tbl_contract_user_conf.user_id) AND (tbl_contracts.id = tbl_contract_user_conf.contract_id));


ALTER TABLE public.view_find_contract_the_user_belongs_to OWNER TO "licenseMgt";

--
-- Name: view_find_license_flag_set_defined_to_contract; Type: VIEW; Schema: public; Owner: licenseMgt
--

CREATE VIEW public.view_find_license_flag_set_defined_to_contract AS
 SELECT tbl_license_flag_set_defined_contract_conf.contract_id,
    tbl_contracts.title,
    tbl_license_flag_set_defined_contract_conf.license_flag_set_defined_id,
    tbl_license_flag_set_defined.create_date
   FROM public.tbl_contracts,
    public.tbl_license_flag_set_defined_contract_conf,
    public.tbl_license_flag_set_defined
  WHERE ((tbl_license_flag_set_defined_contract_conf.license_flag_set_defined_id = tbl_license_flag_set_defined.id) AND (tbl_license_flag_set_defined_contract_conf.contract_id = tbl_contracts.id));


ALTER TABLE public.view_find_license_flag_set_defined_to_contract OWNER TO "licenseMgt";

--
-- Name: view_find_license_flag_set_issued_to_computer; Type: VIEW; Schema: public; Owner: licenseMgt
--

CREATE VIEW public.view_find_license_flag_set_issued_to_computer AS
 SELECT tbl_license_flag_set_issued_computer_conf.computer_id,
    tbl_computers.name,
    tbl_license_flag_set_issued_computer_conf.license_flag_set_issued_id,
    tbl_license_flag_set_issued.create_date
   FROM public.tbl_computers,
    public.tbl_license_flag_set_issued_computer_conf,
    public.tbl_license_flag_set_issued
  WHERE ((tbl_license_flag_set_issued_computer_conf.license_flag_set_issued_id = tbl_license_flag_set_issued.id) AND (tbl_license_flag_set_issued_computer_conf.computer_id = tbl_computers.id));


ALTER TABLE public.view_find_license_flag_set_issued_to_computer OWNER TO "licenseMgt";

--
-- Name: view_find_license_flag_set_issued_to_user; Type: VIEW; Schema: public; Owner: licenseMgt
--

CREATE VIEW public.view_find_license_flag_set_issued_to_user AS
 SELECT tbl_license_flag_set_issued_user_conf.user_id,
    tbl_users.email_address,
    tbl_license_flag_set_issued_user_conf.license_flag_set_issued_id,
    tbl_license_flag_set_issued.valid_until_date,
    tbl_license_flag_set_issued.create_date
   FROM public.tbl_users,
    public.tbl_license_flag_set_issued_user_conf,
    public.tbl_license_flag_set_issued
  WHERE ((tbl_license_flag_set_issued_user_conf.license_flag_set_issued_id = tbl_license_flag_set_issued.id) AND (tbl_license_flag_set_issued_user_conf.user_id = tbl_users.id));


ALTER TABLE public.view_find_license_flag_set_issued_to_user OWNER TO "licenseMgt";

--
-- Name: view_flags_in_defined_lfs; Type: VIEW; Schema: public; Owner: licenseMgt
--

CREATE VIEW public.view_flags_in_defined_lfs AS
 SELECT tbl_license_flag.id,
    tbl_license_flag.title,
    tbl_license_flag.title_in_kmsecurity AS kmtitle,
    tbl_license_flag_set_defined_conf.license_flag_set_defined_id AS defined_id
   FROM public.tbl_license_flag,
    public.tbl_license_flag_set_defined_conf
  WHERE (tbl_license_flag.id = tbl_license_flag_set_defined_conf.license_flag_id)
  ORDER BY tbl_license_flag.title;


ALTER TABLE public.view_flags_in_defined_lfs OWNER TO "licenseMgt";

--
-- Name: VIEW view_flags_in_defined_lfs; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON VIEW public.view_flags_in_defined_lfs IS 'list license flags in defined_license_flag_sets';


--
-- Name: view_flags_in_issued_lfs; Type: VIEW; Schema: public; Owner: licenseMgt
--

CREATE VIEW public.view_flags_in_issued_lfs AS
 SELECT tbl_license_flag.id,
    tbl_license_flag.title,
    tbl_license_flag.title_in_kmsecurity AS kmtitle,
    tbl_license_flag_set_issued_conf.license_flag_set_issued_id AS issued_id
   FROM public.tbl_license_flag,
    public.tbl_license_flag_set_issued_conf
  WHERE (tbl_license_flag.id = tbl_license_flag_set_issued_conf.license_flag_id)
  ORDER BY tbl_license_flag.title;


ALTER TABLE public.view_flags_in_issued_lfs OWNER TO "licenseMgt";

--
-- Name: VIEW view_flags_in_issued_lfs; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON VIEW public.view_flags_in_issued_lfs IS 'list license flags in issued_license_flag_sets';


--
-- Data for Name: tbl_admin; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_admin (id, logon, password) FROM stdin;
\.
COPY public.tbl_admin (id, logon, password) FROM '$$PATH$$/3588.dat';

--
-- Data for Name: tbl_computers; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_computers (id, name, mac_address, project_indication, serial_number, blocked, create_date, memo, inactive) FROM stdin;
\.
COPY public.tbl_computers (id, name, mac_address, project_indication, serial_number, blocked, create_date, memo, inactive) FROM '$$PATH$$/3576.dat';

--
-- Data for Name: tbl_contact_person; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_contact_person (id, last_name, first_name, e_mail, gid_number, create_date, memo, inactive) FROM stdin;
\.
COPY public.tbl_contact_person (id, last_name, first_name, e_mail, gid_number, create_date, memo, inactive) FROM '$$PATH$$/3590.dat';

--
-- Data for Name: tbl_contract_contact_person_conf; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_contract_contact_person_conf (contract_id, contact_person_id) FROM stdin;
\.
COPY public.tbl_contract_contact_person_conf (contract_id, contact_person_id) FROM '$$PATH$$/3568.dat';

--
-- Data for Name: tbl_contract_user_conf; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_contract_user_conf (contract_id, user_id) FROM stdin;
\.
COPY public.tbl_contract_user_conf (contract_id, user_id) FROM '$$PATH$$/3574.dat';

--
-- Data for Name: tbl_contracts; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_contracts (id, title, description, expiration_date, user_is_internal, additional_security_required, user_has_conopt, use_default_distribution_channel, create_date, memo, valid_version, require_km3dv_license, km3dv_licensed_components_text, inactive) FROM stdin;
\.
COPY public.tbl_contracts (id, title, description, expiration_date, user_is_internal, additional_security_required, user_has_conopt, use_default_distribution_channel, create_date, memo, valid_version, require_km3dv_license, km3dv_licensed_components_text, inactive) FROM '$$PATH$$/3578.dat';

--
-- Data for Name: tbl_license_flag; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_license_flag (id, title, title_in_kmsecurity, description, memo, external_use_information, internal_use_information) FROM stdin;
\.
COPY public.tbl_license_flag (id, title, title_in_kmsecurity, description, memo, external_use_information, internal_use_information) FROM '$$PATH$$/3580.dat';

--
-- Data for Name: tbl_license_flag_set_defined; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_license_flag_set_defined (id, create_date, memo) FROM stdin;
\.
COPY public.tbl_license_flag_set_defined (id, create_date, memo) FROM '$$PATH$$/3582.dat';

--
-- Data for Name: tbl_license_flag_set_defined_conf; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_license_flag_set_defined_conf (license_flag_set_defined_id, license_flag_id) FROM stdin;
\.
COPY public.tbl_license_flag_set_defined_conf (license_flag_set_defined_id, license_flag_id) FROM '$$PATH$$/3572.dat';

--
-- Data for Name: tbl_license_flag_set_defined_contract_conf; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_license_flag_set_defined_contract_conf (license_flag_set_defined_id, contract_id) FROM stdin;
\.
COPY public.tbl_license_flag_set_defined_contract_conf (license_flag_set_defined_id, contract_id) FROM '$$PATH$$/3569.dat';

--
-- Data for Name: tbl_license_flag_set_issued; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_license_flag_set_issued (id, valid_until_date, valid_version, create_date, memo) FROM stdin;
\.
COPY public.tbl_license_flag_set_issued (id, valid_until_date, valid_version, create_date, memo) FROM '$$PATH$$/3584.dat';

--
-- Data for Name: tbl_license_flag_set_issued_computer_conf; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_license_flag_set_issued_computer_conf (license_flag_set_issued_id, computer_id) FROM stdin;
\.
COPY public.tbl_license_flag_set_issued_computer_conf (license_flag_set_issued_id, computer_id) FROM '$$PATH$$/3570.dat';

--
-- Data for Name: tbl_license_flag_set_issued_conf; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_license_flag_set_issued_conf (license_flag_set_issued_id, license_flag_id) FROM stdin;
\.
COPY public.tbl_license_flag_set_issued_conf (license_flag_set_issued_id, license_flag_id) FROM '$$PATH$$/3573.dat';

--
-- Data for Name: tbl_license_flag_set_issued_user_conf; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_license_flag_set_issued_user_conf (license_flag_set_issued_id, user_id) FROM stdin;
\.
COPY public.tbl_license_flag_set_issued_user_conf (license_flag_set_issued_id, user_id) FROM '$$PATH$$/3571.dat';

--
-- Data for Name: tbl_user_computer_conf; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_user_computer_conf (user_id, computer_id) FROM stdin;
\.
COPY public.tbl_user_computer_conf (user_id, computer_id) FROM '$$PATH$$/3567.dat';

--
-- Data for Name: tbl_users; Type: TABLE DATA; Schema: public; Owner: licenseMgt
--

COPY public.tbl_users (id, last_name, first_name, logon_name, email_address, gid_number, blocked, create_date, memo, inactive) FROM stdin;
\.
COPY public.tbl_users (id, last_name, first_name, logon_name, email_address, gid_number, blocked, create_date, memo, inactive) FROM '$$PATH$$/3586.dat';

--
-- Name: tbladmin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: licenseMgt
--

SELECT pg_catalog.setval('public.tbladmin_id_seq', 12, true);


--
-- Name: tblcomputers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: licenseMgt
--

SELECT pg_catalog.setval('public.tblcomputers_id_seq', 6289, true);


--
-- Name: tblcontactperson_id_seq; Type: SEQUENCE SET; Schema: public; Owner: licenseMgt
--

SELECT pg_catalog.setval('public.tblcontactperson_id_seq', 46, true);


--
-- Name: tblcontracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: licenseMgt
--

SELECT pg_catalog.setval('public.tblcontracts_id_seq', 281, true);


--
-- Name: tbllicenseflag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: licenseMgt
--

SELECT pg_catalog.setval('public.tbllicenseflag_id_seq', 93, true);


--
-- Name: tbllicenseflagsetdefined_id_seq; Type: SEQUENCE SET; Schema: public; Owner: licenseMgt
--

SELECT pg_catalog.setval('public.tbllicenseflagsetdefined_id_seq', 670, true);


--
-- Name: tbllicenseflagsetissued_id_seq; Type: SEQUENCE SET; Schema: public; Owner: licenseMgt
--

SELECT pg_catalog.setval('public.tbllicenseflagsetissued_id_seq', 10800, true);


--
-- Name: tblusers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: licenseMgt
--

SELECT pg_catalog.setval('public.tblusers_id_seq', 3627, true);


--
-- Name: tbl_contracts PK_tblContracts; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_contracts
    ADD CONSTRAINT "PK_tblContracts" PRIMARY KEY (id);


--
-- Name: tbl_license_flag PK_tblLicenseFlag; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag
    ADD CONSTRAINT "PK_tblLicenseFlag" PRIMARY KEY (id);


--
-- Name: tbl_license_flag_set_issued PK_tblLicenseFlagSetIssued; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_issued
    ADD CONSTRAINT "PK_tblLicenseFlagSetIssued" PRIMARY KEY (id);


--
-- Name: tbl_users PK_tblUsers; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_users
    ADD CONSTRAINT "PK_tblUsers" PRIMARY KEY (id);


--
-- Name: tbl_contracts Title_unique; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_contracts
    ADD CONSTRAINT "Title_unique" UNIQUE (title);


--
-- Name: tbl_users email2logonname; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_users
    ADD CONSTRAINT email2logonname UNIQUE (logon_name, email_address);


--
-- Name: CONSTRAINT email2logonname ON tbl_users; Type: COMMENT; Schema: public; Owner: licenseMgt
--

COMMENT ON CONSTRAINT email2logonname ON public.tbl_users IS 'one email address can be assigne only once to a logonname, vice versa';


--
-- Name: tbl_license_flag_set_defined_contract_conf lfs_defined_once; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_defined_contract_conf
    ADD CONSTRAINT lfs_defined_once UNIQUE (license_flag_set_defined_id);


--
-- Name: tbl_computers pk_tbl_Computers; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_computers
    ADD CONSTRAINT "pk_tbl_Computers" PRIMARY KEY (id);


--
-- Name: tbl_contact_person pk_tbl_contact_person; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_contact_person
    ADD CONSTRAINT pk_tbl_contact_person PRIMARY KEY (id);


--
-- Name: tbl_contract_user_conf tblContract_User_Conf_ContractID_UserID_key; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_contract_user_conf
    ADD CONSTRAINT "tblContract_User_Conf_ContractID_UserID_key" UNIQUE (contract_id, user_id);


--
-- Name: tbl_license_flag_set_issued_computer_conf tblLicenseFlagSetIssued_Compu_LicenseFlagSetIssuedID_Comput_key; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_issued_computer_conf
    ADD CONSTRAINT "tblLicenseFlagSetIssued_Compu_LicenseFlagSetIssuedID_Comput_key" UNIQUE (license_flag_set_issued_id, computer_id);


--
-- Name: tbl_license_flag_set_issued_user_conf tblLicenseFlagSetIssued_User__LicenseFlagSetIssuedID_UserID_key; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_issued_user_conf
    ADD CONSTRAINT "tblLicenseFlagSetIssued_User__LicenseFlagSetIssuedID_UserID_key" UNIQUE (license_flag_set_issued_id, user_id);


--
-- Name: tbl_license_flag_set_issued_conf tblLicenseFlagSet_Conf_LicenseFlagSetIssuedID_LicenseFlagID_key; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_issued_conf
    ADD CONSTRAINT "tblLicenseFlagSet_Conf_LicenseFlagSetIssuedID_LicenseFlagID_key" UNIQUE (license_flag_set_issued_id, license_flag_id);


--
-- Name: tbl_license_flag tblLicenseFlag_TitleInKMSecurity_key; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag
    ADD CONSTRAINT "tblLicenseFlag_TitleInKMSecurity_key" UNIQUE (title_in_kmsecurity);


--
-- Name: tbl_license_flag tblLicenseFlag_Title_key; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag
    ADD CONSTRAINT "tblLicenseFlag_Title_key" UNIQUE (title);


--
-- Name: tbl_user_computer_conf tblUser_Computer_Conf_UserID_ComputerID_key; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_user_computer_conf
    ADD CONSTRAINT "tblUser_Computer_Conf_UserID_ComputerID_key" UNIQUE (user_id, computer_id);


--
-- Name: tbl_admin tbl_admin_id_key; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_admin
    ADD CONSTRAINT tbl_admin_id_key UNIQUE (id);


--
-- Name: tbl_admin tbl_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_admin
    ADD CONSTRAINT tbl_admin_pkey PRIMARY KEY (id);


--
-- Name: tbl_computers tbl_computers_name_key; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_computers
    ADD CONSTRAINT tbl_computers_name_key UNIQUE (name);


--
-- Name: tbl_contract_contact_person_conf tbl_contract_contact_person_c_contract_id_contact_person_id_key; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_contract_contact_person_conf
    ADD CONSTRAINT tbl_contract_contact_person_c_contract_id_contact_person_id_key UNIQUE (contract_id, contact_person_id);


--
-- Name: tbl_license_flag_set_defined tbl_license_flag_set_defined_pkey; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_defined
    ADD CONSTRAINT tbl_license_flag_set_defined_pkey PRIMARY KEY (id);


--
-- Name: tbl_license_flag_set_defined_conf tbl_unique_pair; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_defined_conf
    ADD CONSTRAINT tbl_unique_pair UNIQUE (license_flag_set_defined_id, license_flag_id);


--
-- Name: tbl_license_flag_set_defined_contract_conf unique_pair; Type: CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_defined_contract_conf
    ADD CONSTRAINT unique_pair UNIQUE (license_flag_set_defined_id, contract_id);


--
-- Name: IXFK_tblContract_ContactPerson_Conf_tblContactPerson; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblContract_ContactPerson_Conf_tblContactPerson" ON public.tbl_contract_contact_person_conf USING btree (contact_person_id);


--
-- Name: IXFK_tblContract_ContactPerson_Conf_tblContracts; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblContract_ContactPerson_Conf_tblContracts" ON public.tbl_contract_contact_person_conf USING btree (contract_id);


--
-- Name: IXFK_tblContract_User_Conf_tblContracts; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblContract_User_Conf_tblContracts" ON public.tbl_contract_user_conf USING btree (contract_id);


--
-- Name: IXFK_tblContract_User_Conf_tblUsers; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblContract_User_Conf_tblUsers" ON public.tbl_contract_user_conf USING btree (user_id);


--
-- Name: IXFK_tblLicenseFlagSetIssued_Computer_Conf_tblComputers; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblLicenseFlagSetIssued_Computer_Conf_tblComputers" ON public.tbl_license_flag_set_issued_computer_conf USING btree (computer_id);


--
-- Name: IXFK_tblLicenseFlagSetIssued_Computer_Conf_tblLicenseFlagSetIss; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblLicenseFlagSetIssued_Computer_Conf_tblLicenseFlagSetIss" ON public.tbl_license_flag_set_issued_computer_conf USING btree (license_flag_set_issued_id);


--
-- Name: IXFK_tblLicenseFlagSetIssued_User_Conf_tblLicenseFlagSetIssued; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblLicenseFlagSetIssued_User_Conf_tblLicenseFlagSetIssued" ON public.tbl_license_flag_set_issued_user_conf USING btree (license_flag_set_issued_id);


--
-- Name: IXFK_tblLicenseFlagSetIssued_User_Conf_tblUsers; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblLicenseFlagSetIssued_User_Conf_tblUsers" ON public.tbl_license_flag_set_issued_user_conf USING btree (user_id);


--
-- Name: IXFK_tblLicenseFlagSet_Conf_tblLicenseFlag; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblLicenseFlagSet_Conf_tblLicenseFlag" ON public.tbl_license_flag_set_issued_conf USING btree (license_flag_id);


--
-- Name: IXFK_tblLicenseFlagSet_Conf_tblLicenseFlagSetIssued; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblLicenseFlagSet_Conf_tblLicenseFlagSetIssued" ON public.tbl_license_flag_set_issued_conf USING btree (license_flag_set_issued_id);


--
-- Name: IXFK_tblUser_Computer_Conf_tblComputers; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblUser_Computer_Conf_tblComputers" ON public.tbl_user_computer_conf USING btree (computer_id);


--
-- Name: IXFK_tblUser_Computer_Conf_tblUsers; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX "IXFK_tblUser_Computer_Conf_tblUsers" ON public.tbl_user_computer_conf USING btree (user_id);


--
-- Name: fki_fk_contract_id; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX fki_fk_contract_id ON public.tbl_license_flag_set_defined_contract_conf USING btree (contract_id);


--
-- Name: fki_fk_lfs_defined; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX fki_fk_lfs_defined ON public.tbl_license_flag_set_defined_contract_conf USING btree (license_flag_set_defined_id);


--
-- Name: fki_flg_id; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX fki_flg_id ON public.tbl_license_flag_set_defined_conf USING btree (license_flag_id);


--
-- Name: fki_lfs_defined_id; Type: INDEX; Schema: public; Owner: licenseMgt
--

CREATE INDEX fki_lfs_defined_id ON public.tbl_license_flag_set_defined_conf USING btree (license_flag_set_defined_id);


--
-- Name: tbl_contract_user_conf FK_tblContract_User_Conf_tblContracts; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_contract_user_conf
    ADD CONSTRAINT "FK_tblContract_User_Conf_tblContracts" FOREIGN KEY (contract_id) REFERENCES public.tbl_contracts(id);


--
-- Name: tbl_contract_user_conf FK_tblContract_User_Conf_tblUsers; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_contract_user_conf
    ADD CONSTRAINT "FK_tblContract_User_Conf_tblUsers" FOREIGN KEY (user_id) REFERENCES public.tbl_users(id);


--
-- Name: tbl_license_flag_set_issued_computer_conf FK_tblLicenseFlagSetIssued_Computer_Conf_tblComputers; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_issued_computer_conf
    ADD CONSTRAINT "FK_tblLicenseFlagSetIssued_Computer_Conf_tblComputers" FOREIGN KEY (computer_id) REFERENCES public.tbl_computers(id);


--
-- Name: tbl_license_flag_set_issued_computer_conf FK_tblLicenseFlagSetIssued_Computer_Conf_tblLicenseFlagSetIssue; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_issued_computer_conf
    ADD CONSTRAINT "FK_tblLicenseFlagSetIssued_Computer_Conf_tblLicenseFlagSetIssue" FOREIGN KEY (license_flag_set_issued_id) REFERENCES public.tbl_license_flag_set_issued(id);


--
-- Name: tbl_license_flag_set_issued_user_conf FK_tblLicenseFlagSetIssued_User_Conf_tblLicenseFlagSetIssued; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_issued_user_conf
    ADD CONSTRAINT "FK_tblLicenseFlagSetIssued_User_Conf_tblLicenseFlagSetIssued" FOREIGN KEY (license_flag_set_issued_id) REFERENCES public.tbl_license_flag_set_issued(id);


--
-- Name: tbl_license_flag_set_issued_user_conf FK_tblLicenseFlagSetIssued_User_Conf_tblUsers; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_issued_user_conf
    ADD CONSTRAINT "FK_tblLicenseFlagSetIssued_User_Conf_tblUsers" FOREIGN KEY (user_id) REFERENCES public.tbl_users(id);


--
-- Name: tbl_license_flag_set_issued_conf FK_tblLicenseFlagSet_Conf_tblLicenseFlag; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_issued_conf
    ADD CONSTRAINT "FK_tblLicenseFlagSet_Conf_tblLicenseFlag" FOREIGN KEY (license_flag_id) REFERENCES public.tbl_license_flag(id);


--
-- Name: tbl_license_flag_set_issued_conf FK_tblLicenseFlagSet_Conf_tblLicenseFlagSetIssued; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_issued_conf
    ADD CONSTRAINT "FK_tblLicenseFlagSet_Conf_tblLicenseFlagSetIssued" FOREIGN KEY (license_flag_set_issued_id) REFERENCES public.tbl_license_flag_set_issued(id);


--
-- Name: tbl_user_computer_conf FK_tblUser_Computer_Conf_tblComputers; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_user_computer_conf
    ADD CONSTRAINT "FK_tblUser_Computer_Conf_tblComputers" FOREIGN KEY (computer_id) REFERENCES public.tbl_computers(id);


--
-- Name: tbl_user_computer_conf FK_tblUser_Computer_Conf_tblUsers; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_user_computer_conf
    ADD CONSTRAINT "FK_tblUser_Computer_Conf_tblUsers" FOREIGN KEY (user_id) REFERENCES public.tbl_users(id);


--
-- Name: tbl_license_flag_set_defined_contract_conf fk_contract_id; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_defined_contract_conf
    ADD CONSTRAINT fk_contract_id FOREIGN KEY (contract_id) REFERENCES public.tbl_contracts(id);


--
-- Name: tbl_license_flag_set_defined_contract_conf fk_lfs_defined; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_defined_contract_conf
    ADD CONSTRAINT fk_lfs_defined FOREIGN KEY (license_flag_set_defined_id) REFERENCES public.tbl_license_flag_set_defined(id);


--
-- Name: tbl_contract_contact_person_conf fk_tbl_contract_contact_person_conf_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_contract_contact_person_conf
    ADD CONSTRAINT fk_tbl_contract_contact_person_conf_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.tbl_contracts(id);


--
-- Name: tbl_contract_contact_person_conf fk_tbl_contract_contact_person_conf_tbl_contact_person; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_contract_contact_person_conf
    ADD CONSTRAINT fk_tbl_contract_contact_person_conf_tbl_contact_person FOREIGN KEY (contact_person_id) REFERENCES public.tbl_contact_person(id);


--
-- Name: tbl_license_flag_set_defined_conf flg_id; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_defined_conf
    ADD CONSTRAINT flg_id FOREIGN KEY (license_flag_id) REFERENCES public.tbl_license_flag(id);


--
-- Name: tbl_license_flag_set_defined_conf lfs_defined_id; Type: FK CONSTRAINT; Schema: public; Owner: licenseMgt
--

ALTER TABLE ONLY public.tbl_license_flag_set_defined_conf
    ADD CONSTRAINT lfs_defined_id FOREIGN KEY (license_flag_set_defined_id) REFERENCES public.tbl_license_flag_set_defined(id);


--
-- Name: TABLE tbl_user_computer_conf; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_user_computer_conf TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_contract_contact_person_conf; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_contract_contact_person_conf TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_license_flag_set_defined_contract_conf; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_license_flag_set_defined_contract_conf TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_license_flag_set_issued_computer_conf; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_license_flag_set_issued_computer_conf TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_license_flag_set_issued_user_conf; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_license_flag_set_issued_user_conf TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_license_flag_set_defined_conf; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_license_flag_set_defined_conf TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_license_flag_set_issued_conf; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_license_flag_set_issued_conf TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_contract_user_conf; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_contract_user_conf TO "BackupAdminReadOnly";


--
-- Name: SEQUENCE tblcomputers_id_seq; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON SEQUENCE public.tblcomputers_id_seq TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_computers; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_computers TO "BackupAdminReadOnly";


--
-- Name: SEQUENCE tblcontracts_id_seq; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON SEQUENCE public.tblcontracts_id_seq TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_contracts; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_contracts TO "BackupAdminReadOnly";


--
-- Name: SEQUENCE tbllicenseflag_id_seq; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON SEQUENCE public.tbllicenseflag_id_seq TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_license_flag; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_license_flag TO "BackupAdminReadOnly";


--
-- Name: SEQUENCE tbllicenseflagsetdefined_id_seq; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON SEQUENCE public.tbllicenseflagsetdefined_id_seq TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_license_flag_set_defined; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_license_flag_set_defined TO "BackupAdminReadOnly";


--
-- Name: TABLE view_flag_to_contract; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.view_flag_to_contract TO "BackupAdminReadOnly";


--
-- Name: SEQUENCE tbllicenseflagsetissued_id_seq; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON SEQUENCE public.tbllicenseflagsetissued_id_seq TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_license_flag_set_issued; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_license_flag_set_issued TO "BackupAdminReadOnly";


--
-- Name: SEQUENCE tblusers_id_seq; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON SEQUENCE public.tblusers_id_seq TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_users; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_users TO "BackupAdminReadOnly";


--
-- Name: TABLE view_flag_to_user; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.view_flag_to_user TO "BackupAdminReadOnly";


--
-- Name: SEQUENCE tbladmin_id_seq; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON SEQUENCE public.tbladmin_id_seq TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_admin; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_admin TO "BackupAdminReadOnly";


--
-- Name: SEQUENCE tblcontactperson_id_seq; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON SEQUENCE public.tblcontactperson_id_seq TO "BackupAdminReadOnly";


--
-- Name: TABLE tbl_contact_person; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.tbl_contact_person TO "BackupAdminReadOnly";


--
-- Name: TABLE view_computers_with_users; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.view_computers_with_users TO "BackupAdminReadOnly";


--
-- Name: TABLE view_find_contract_the_user_belongs_to; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.view_find_contract_the_user_belongs_to TO "BackupAdminReadOnly";


--
-- Name: TABLE view_find_license_flag_set_defined_to_contract; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.view_find_license_flag_set_defined_to_contract TO "BackupAdminReadOnly";


--
-- Name: TABLE view_find_license_flag_set_issued_to_computer; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.view_find_license_flag_set_issued_to_computer TO "BackupAdminReadOnly";


--
-- Name: TABLE view_find_license_flag_set_issued_to_user; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.view_find_license_flag_set_issued_to_user TO "BackupAdminReadOnly";


--
-- Name: TABLE view_flags_in_defined_lfs; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.view_flags_in_defined_lfs TO "BackupAdminReadOnly";


--
-- Name: TABLE view_flags_in_issued_lfs; Type: ACL; Schema: public; Owner: licenseMgt
--

GRANT SELECT ON TABLE public.view_flags_in_issued_lfs TO "BackupAdminReadOnly";


--
-- PostgreSQL database dump complete
--

